
import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to LearnFirst</h1>
      <p>Your platform to learn anything online.</p>
    </div>
  );
}

export default Home;
